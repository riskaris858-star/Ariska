<?php
session_start();
include 'koneksi.php';

if(isset($_POST['tombol'])){
    $nis   = mysqli_real_escape_string($koneksi, trim($_POST['nis']));
    $kelas = mysqli_real_escape_string($koneksi, trim($_POST['kelas']));

    if(empty($nis) || empty($kelas)){
        $_SESSION['error'] = "❌ NIS dan Kelas wajib diisi!";
        header("Location: cek-pengaduan.php");
        exit;
    }

    $sql   = "SELECT * FROM siswa WHERE nis = '$nis' AND kelas = '$kelas'";
    $query = mysqli_query($koneksi, $sql);

    if(mysqli_num_rows($query) > 0){
        $_SESSION['nis'] = $nis;
        header("Location: data-pengaduan.php");
        exit;
    } else {
        $_SESSION['error'] = "❌ Maaf Kombinasi NIS dan Kelas salah";
        header("Location: cek-pengaduan.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cek Pengaduan</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="vh-100 d-flex justify-content-center align-items-center">
    <form action="" method="post" class="col-md-4 bg-white border rounded-4 p-4 shadow-sm">

        <h3 class="text-center">Cek Pengaduan</h3>
        <p class="text-muted text-center">Aplikasi Pengaduan Sarana Sekolah</p>
        <hr>

        <?php if(isset($_SESSION['error'])) { ?>
            <div class="alert alert-danger text-center">
                <?= $_SESSION['error']; ?>
            </div>
        <?php unset($_SESSION['error']); } ?>

        <div class="mb-3">
            <label class="form-label">NIS</label>
            <input type="text" name="nis" class="form-control" required placeholder="Masukkan NIS">
        </div>

        <div class="mb-3">
            <label class="form-label">Kelas</label>
            <select name="kelas" class="form-select" required>
                <option value="">=== Pilih Kelas ===</option>
                <option value="X RPL 1">X RPL 1</option>
                <option value="X RPL 2">X RPL 2</option>
            </select>
        </div>

        <div class="d-grid mt-4">
            <button type="submit" name="tombol" class="btn btn-primary">Cek Pengaduan</button>
        </div>

    </form>
</div>

<script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>