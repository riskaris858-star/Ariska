<?php
session_start();

if (!isset($_SESSION['login']) || $_SESSION['login'] == false) {
    $_SESSION['error'] = "❌ Maaf anda harus login dulu";
    header('location:../login-admin.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"> <!-- FIX -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin</title>

    <!-- FIX Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- FIX Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <style>
        .nv-link {
            background-color: cadetblue; /* FIX */
            margin-right: 5px;
            color: white !important;
            border-radius: 8px;
            padding: 8px 15px;
            text-decoration: none; /* FIX */
            display: inline-block;
            transition: 0.3s;
        }

        .nv-link:hover {
            background-color: #4b8082;
            color: white !important;
        }
    </style>
</head>

<body>

<nav class="navbar navbar-expand-lg navbar-light bg-light shadow-sm">
    <div class="container-fluid">
        <a class="navbar-brand text-muted fw-bold" href="#">
            Aplikasi Pengaduan Sarana Sekolah
        </a>

        <button class="navbar-toggler" type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarID">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarID">
            <div class="navbar-nav ms-auto">

                <!-- FIX LINK -->
                <a class="nv-link" href="dashboard.php">
                    <i class="fas fa-home me-1"></i> Home
                </a>

                <a class="nv-link" href="?page=kategori">
                    <i class="fas fa-tags me-1"></i> Kategori Pengaduan
                </a>

                <a class="nv-link" href="?page=pengaduan">
                    <i class="fas fa-comment-dots me-1"></i> Pengaduan
                </a>

                <a class="nv-link" href="logout.php">
                    <i class="fas fa-power-off me-1"></i> Logout
                </a>

            </div>
        </div>
    </div>
</nav>

<div class="container border shadow-lg w-100 p-5 rounded-3 mt-4">

<?php
$page = isset($_GET['page']) ? $_GET['page'] : '';

if ($page && file_exists($page . ".php")) {
    include $page . ".php";
} else {
?>
    <h4>Selamat Datang Admin 👋</h4>
    <p class="text-muted fst-italic">
        Pengelolaan pengaduan sarana sekolah digunakan untuk menerima,
        memverifikasi dan menindaklanjuti laporan atas kerusakan dan kendala
        fisik sekolah secara terstruktur dan terdokumentasi.
    </p>
<?php } ?>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>