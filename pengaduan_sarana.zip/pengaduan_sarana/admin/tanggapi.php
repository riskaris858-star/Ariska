<?php
include 'akses.php';
include '../koneksi.php';

// 1. Definisikan ID dari URL
$id = $_GET['id'];

// 2. LOGIKA UPDATE (Diletakkan di atas agar data terbaru langsung tampil)
if (isset($_POST['tombol'])) {
    $status = $_POST['status'];
    $feedback = $_POST['feedback'];
    
    $update = mysqli_query($koneksi, "UPDATE aspirasi SET 
              status='$status', 
              feedback='$feedback' 
              WHERE id_pelaporan='$id'");

    if ($update) {
        echo "<script>
                alert('✅ Feedback berhasil tersimpan / terkirim');
                window.location.assign('?page=pengaduan');
              </script>";
    } else {
        echo "<script>
                alert('❌ Feedback gagal tersimpan / terkirim');
                window.location.assign('?page=pengaduan');
              </script>";
    }
}

// 3. FUNGSI STATUS
function status($status){
    $status = strtolower($status);
    if($status == "menunggu"){
        return "<span class='badge bg-warning text-dark'> 🕒 Menunggu</span>";
    }elseif($status == "proses"){
        return "<span class='badge bg-info text-dark'> ⚙️ Proses</span>";
    }else{
        return "<span class='badge bg-success'> ✅ Selesai</span>";
    }
}

// 4. QUERY SELECT DATA
$sql = "SELECT * FROM input_aspirasi 
        JOIN kategori ON kategori.id_kategori = input_aspirasi.id_kategori
        JOIN aspirasi ON aspirasi.id_pelaporan = input_aspirasi.id_pelaporan
        JOIN siswa ON siswa.nis = input_aspirasi.nis
        WHERE input_aspirasi.id_pelaporan = '$id'
        LIMIT 1";

$query = mysqli_query($koneksi, $sql);
$data = mysqli_fetch_array($query);
?>

<h4 class="text-center mb-4"><i class="fa fa-comments"></i> Tanggapi Pengaduan</h4>

<form method="post" action="">
    <div class="row">
        <div class="col-md-3 fw-bold mb-1">NIS</div>
        <div class="col-md-9">: <?= $data['nis'] ?></div>

        <div class="col-md-3 fw-bold mb-1">Kelas</div>
        <div class="col-md-9">: <?= $data['kelas'] ?></div>

        <div class="col-md-3 fw-bold mb-1">Kategori Pengaduan</div>
        <div class="col-md-9">: <?= $data['ket_kategori'] ?></div>

        <div class="col-md-3 fw-bold mb-1">Status</div>
        <div class="col-md-9">: <?= status($data['status']) ?></div>

        <div class="col-md-3 fw-bold mb-1">Lokasi</div>
        <div class="col-md-9">: <?= $data['lokasi'] ?></div>

        <div class="col-md-3 fw-bold mb-1"><i class="fa fa-lightbulb"></i> Pengaduan</div>
        <div class="col-md-12 p-3 border mb-3 bg-light"><?= $data['ket'] ?></div>

        <div class="col-md-3 fw-bold mb-1"><i class="fa fa-comment"></i> Feedback</div>
        <div class="col-md-12">
            <select name="status" class="form-control mb-2" required>
                <option value="Menunggu" <?= ($data['status'] == 'Menunggu') ? 'selected' : '' ?>>Menunggu</option>
                <option value="Proses" <?= ($data['status'] == 'Proses') ? 'selected' : '' ?>>Proses</option>
                <option value="Selesai" <?= ($data['status'] == 'Selesai') ? 'selected' : '' ?>>Selesai</option>
            </select>

            <textarea name="feedback" class="form-control mb-3" rows="5" placeholder="Masukkan Feedback" required><?= $data['feedback'] ?? '' ?></textarea>

            <button type="submit" name="tombol" class="btn btn-success w-100 mt-4">
                <i class="fa fa-paper-plane"></i> KIRIM
            </button>
        </div>
    </div>
</form>