<?php
include 'akses.php';
include '../koneksi.php';
?>

<h4 class="text-center mb-3">
    <i class="fa fa-tags"></i> Kategori Pengaduan
</h4>

<a href="?page=tambah-kategori" class="btn btn-secondary mt-2 mb-3">
    <i class="fa fa-plus"></i> Tambah Kategori
</a>

<table class="table table-bordered table-light">
<tr class="fw-bold text-center">
    <td>No</td>
    <td>Kategori</td>
    <td>Kelola</td>
</tr>

<?php
$no = 1;
$data = mysqli_query($koneksi, "SELECT * FROM kategori ORDER BY id_kategori DESC");

foreach ($data as $kategori) {
?>

<tr>
    <td><?= $no++ ?></td>
    <td><?= $kategori['ket_kategori'] ?></td>
    <td class="text-center">

        <a class="btn btn-outline-warning btn-sm"
           href="?page=edit-kategori&id=<?= $kategori['id_kategori']; ?>">
           <i class="fa fa-pencil"></i>
        </a>
 
        <a class="btn btn-outline-danger btn-sm"
           href="?page=hapus-kategori&id=<?= $kategori['id_kategori']; ?>"
           onclick="return confirm('Yakin hapus data <?= $kategori['ket_kategori']; ?> ?')">
           <i class="fa fa-trash"></i>
        </a>

    </td>
</tr>

<?php } ?>
</table>