<?php
// PERBAIKAN: Menghapus tag <?php ganda di sini
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include 'akses.php';
include '../koneksi.php';

function status($status){
    if($status=="Menunggu"){
        return "<div class='badge bg-warning text-dark'>⌛ $status</div>";
    }elseif($status=="Proses"){
        return "<div class='badge bg-info text-dark'>🔃 $status</div>";
    }else{
        return "<div class='badge bg-success'>✅ $status</div>";
    }
}
?>

<h4 class="text-center mb-4">Daftar Pengaduan</h4>

<div class="table-responsive">
    <table class="table table-bordered table-striped align-middle">
        <thead class="table-dark">
            <tr class="fw-bold text-center">
                <th>NO</th>
                <th>NIS</th>
                <th>Kelas</th>
                <th>Kategori</th>
                <th>Keterangan</th>
                <th>Status</th>
                <th>Tanggapi</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $no = 1;

        // Query dengan JOIN untuk mengambil data lengkap
        $sql = "SELECT input_aspirasi.*, 
                       aspirasi.status,
                       kategori.ket_kategori
                FROM input_aspirasi
                JOIN aspirasi ON input_aspirasi.id_pelaporan = aspirasi.id_pelaporan
                JOIN kategori ON aspirasi.id_kategori = kategori.id_kategori";

        $data = mysqli_query($koneksi, $sql);

        if(!$data){
            die("Query Error: " . mysqli_error($koneksi));
        }

        if(mysqli_num_rows($data) > 0) {
            while($pengaduan = mysqli_fetch_assoc($data)){ ?>
            <tr class="text-center">
                <td><?= $no++; ?></td>
                <td><?= htmlspecialchars($pengaduan['nis']) ?></td>
                <td><?= htmlspecialchars($pengaduan['kelas'] ?? '-') ?></td>
                <td><?= htmlspecialchars($pengaduan['ket_kategori']) ?></td>
                <td><?= htmlspecialchars($pengaduan['ket']) ?></td>
                <td><?= status($pengaduan['status']) ?></td>
                <td>
                    <a href="?page=tanggapi&id=<?= $pengaduan['id_pelaporan'] ?>" class="btn btn-primary btn-sm">
                        <i class="fas fa-edit"></i> Tanggapi
                    </a>
                </td>
            </tr>
            <?php } 
        } else { ?>
            <tr>
                <td colspan="7" class="text-center">Belum ada data pengaduan.</td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
</div>