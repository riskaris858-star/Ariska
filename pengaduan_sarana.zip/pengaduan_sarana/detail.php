<?php
session_start();
include 'koneksi.php';

if (!isset($_SESSION['nis'])) {
    header("Location: cek-pengaduan.php");
    exit;
}

$id = isset($_GET['id']) ? mysqli_real_escape_string($koneksi, $_GET['id']) : '';

if (empty($id)) {
    die("ID tidak ditemukan!");
}

$sql = "SELECT aspirasi.*,
               input_aspirasi.nis,
               input_aspirasi.lokasi,
               input_aspirasi.ket AS pengaduan,
               siswa.kelas,
               kategori.ket_kategori
        FROM aspirasi
        JOIN input_aspirasi
          ON aspirasi.id_pelaporan = input_aspirasi.id_pelaporan
        JOIN siswa
          ON input_aspirasi.nis = siswa.nis
        JOIN kategori
          ON aspirasi.id_kategori = kategori.id_kategori
        WHERE aspirasi.id_aspirasi = '$id'";

$query = mysqli_query($koneksi, $sql);

// PERBAIKAN: Menghapus tag <?php yang tumpuk di sini
if (!$query) {
    die("Query Error: " . mysqli_error($koneksi));
}

$data = mysqli_fetch_assoc($query);

if (!$data) {
    die("Data pengaduan tidak ditemukan!");
}

$kelas_tampilan = $data['kelas'] ?? '-';

// Fungsi badge status
function statusBadge($status) {
    if ($status == "Menunggu") {
        return "<span class='badge bg-warning text-dark'>Menunggu</span>";
    } elseif ($status == "Proses") {
        return "<span class='badge bg-info text-dark'>Proses</span>";
    } elseif ($status == "Selesai") {
        return "<span class='badge bg-success'>Selesai</span>";
    }
    return "<span class='badge bg-secondary'>Tidak diketahui</span>";
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Detail Pengaduan</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', sans-serif;
            font-size: 14px;
        }

        .card-custom {
            max-width: 650px;
            margin: 30px auto;
            background: white;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.05);
            padding: 20px;
            border: 1px solid #eaeaea;
        }

        h3 { font-size: 18px; font-weight: 600; }
        .info-row { display: flex; padding: 8px 0; border-bottom: 1px solid #f1f1f1; }
        .info-label { width: 180px; font-weight: 600; color: #444; }
        .section-label { font-weight: 600; margin-top: 18px; margin-bottom: 6px; }
        .content-box { border: 1px solid #dee2e6; padding: 10px; border-radius: 6px; min-height: 40px; background-color: #fff; }
        .btn { font-size: 13px; padding: 6px 10px; }
        .badge { font-size: 11px; padding: 5px 8px; }
    </style>
</head>

<body>
<div class="container">
    <div class="card-custom">

        <h3 class="text-center mb-1">
            Data Pengaduan NIS <?= htmlspecialchars($data['nis']) ?>,
            Kelas <?= htmlspecialchars($kelas_tampilan) ?>
        </h3>

        <p class="text-muted text-center small mb-3">
            Aplikasi Pengaduan Sarana Sekolah
        </p>

        <a href="index.php" class="btn btn-primary w-100 mb-3">
            <i class="fas fa-plus"></i> Tambah Pengaduan
        </a>

        <div class="info-row">
            <div class="info-label">NIS</div>
            <div><?= htmlspecialchars($data['nis']) ?></div>
        </div>

        <div class="info-row">
            <div class="info-label">Kelas</div>
            <div><?= htmlspecialchars($kelas_tampilan) ?></div>
        </div>

        <div class="info-row">
            <div class="info-label">Kategori</div>
            <div><?= htmlspecialchars($data['ket_kategori']) ?></div>
        </div>

        <div class="info-row">
            <div class="info-label">Status</div>
            <div><?= statusBadge($data['status']) ?></div>
        </div>

        <div class="info-row">
            <div class="info-label">Lokasi</div>
            <div><?= strtoupper(htmlspecialchars($data['lokasi'])) ?></div>
        </div>

        <label class="section-label">Pengaduan</label>
        <div class="content-box">
            <?= nl2br(htmlspecialchars($data['pengaduan'] ?? 'Tidak ada rincian pengaduan.')) ?>
        </div>

        <label class="section-label">Feedback Admin</label>
        <div class="content-box" style="background-color:#fdfdfd;">
            <?= nl2br(htmlspecialchars($data['feedback'] ?? '-')) ?>
        </div>

        <a href="cek-pengaduan.php" class="btn btn-warning w-100 mt-4 fw-bold text-dark">
            <i class="fas fa-arrow-left"></i> Kembali
        </a>

    </div>
</div>
</body>
</html>