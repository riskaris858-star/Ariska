<?php
session_start();
include 'koneksi.php';

if (!isset($_SESSION['nis'])) {
    header("Location: cek-pengaduan.php");
    exit;
}

function statusBadge($status){ 
    $status = strtolower(trim($status));

    if($status == "menunggu"){
        return "<span class='badge bg-warning text-dark'>
                <i class='bi bi-hourglass-split'></i> menunggu
                </span>";
    }elseif($status == "proses"){
        return "<span class='badge bg-info text-dark'>
                <i class='bi bi-arrow-repeat'></i> proses
                </span>";
    }elseif($status == "selesai"){
        return "<span class='badge bg-success'>
                <i class='bi bi-check-circle'></i> selesai
                </span>";
    }else{
        return "<span class='badge bg-secondary'>belum ada</span>";
    }
}

$nis = $_SESSION['nis'];
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Data Pengaduan</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="bg-white border rounded-4 p-4 shadow-sm">

        <h3 class="text-center">Data Pengaduan</h3>
        <p class="text-muted text-center">Aplikasi Pengaduan Sarana Sekolah</p>

       <a href="index.php" class="btn btn-primary w-100 mb-3">
    ➕ Tambah Pengaduan
</a>
       
       

        <table class="table table-bordered table-striped">
            <thead class="table-light text-center">
                <tr>
                    <th>No</th>
                    <th>Kategori</th>
                    <th>Keterangan</th>
                    <th>Status</th>
                    <th>Detail</th>
                </tr>
            </thead>
            <tbody>

            <?php
            $no = 1;

            $sql = "SELECT * FROM input_aspirasi 
                    JOIN kategori 
                        ON input_aspirasi.id_kategori = kategori.id_kategori 
                    JOIN aspirasi 
                        ON aspirasi.id_pelaporan = input_aspirasi.id_pelaporan 
                    WHERE input_aspirasi.nis = '$nis'";

            $data = mysqli_query($koneksi, $sql);

            if(mysqli_num_rows($data) > 0){
                while($pengaduan = mysqli_fetch_assoc($data)){
            ?>
                <tr>
                    <td class="text-center"><?= $no++; ?></td>
                    <td><?= $pengaduan['ket_kategori']; ?></td>
                    <td><?= $pengaduan['ket']; ?></td>
                    <td class="text-center">
                        <?= statusBadge($pengaduan['status']); ?>
                    </td>
                    <td class="text-center">
                        <a href="detail.php?id=<?= $pengaduan['id_pelaporan']; ?>" 
                           class="btn btn-primary btn-sm">
                            <i class="bi bi-search"></i> Detail
                        </a>
                    </td>
                </tr>
            <?php
                }
            } else {
            ?>
                <tr>
                    <td colspan="5" class="text-center text-muted">
                        Belum ada data pengaduan
                    </td>
                </tr>
            <?php } ?>

            </tbody>
        </table>
<a href="cek-pengaduan.php" class="btn btn-warning w-100">
    ⬅️ Kembali
</a>
        
        
        

    </div>
</div>

</body>
</html>